-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 21, 2019 at 06:04 AM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smarttolldatabase`
--
CREATE DATABASE IF NOT EXISTS `smarttolldatabase` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `smarttolldatabase`;

-- --------------------------------------------------------

--
-- Table structure for table `citylist`
--

DROP TABLE IF EXISTS `citylist`;
CREATE TABLE IF NOT EXISTS `citylist` (
  `City_name` varchar(20) NOT NULL,
  PRIMARY KEY (`City_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `citylist`
--

INSERT INTO `citylist` (`City_name`) VALUES
('Beng'),
('Bengaluru'),
('Goa'),
('Gurgaon'),
('Jabalpur'),
('Kashmir'),
('Mumbai'),
('Pune');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `Emp_id` int(20) NOT NULL,
  `Emp_name` varchar(30) NOT NULL,
  `Emp_pwd` varchar(20) NOT NULL,
  PRIMARY KEY (`Emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Emp_id`, `Emp_name`, `Emp_pwd`) VALUES
(1, 'emp', 'emp'),
(2, 'abc', 'abc'),
(3, 'pqr', 'pqr');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
CREATE TABLE IF NOT EXISTS `payment` (
  `Trans_id` varchar(15) NOT NULL,
  `Tax_amount` int(11) NOT NULL,
  `U_id` int(100) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`Trans_id`),
  KEY `U_id` (`U_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `qr_code`
--

DROP TABLE IF EXISTS `qr_code`;
CREATE TABLE IF NOT EXISTS `qr_code` (
  `QR_id` int(15) NOT NULL,
  `Trans_id` varchar(15) NOT NULL,
  `U_id` int(100) NOT NULL,
  `Veh_Regno` varchar(15) NOT NULL,
  PRIMARY KEY (`QR_id`),
  KEY `Trans_id` (`Trans_id`),
  KEY `U_id` (`U_id`),
  KEY `Veh_Regno` (`Veh_Regno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stadmin`
--

DROP TABLE IF EXISTS `stadmin`;
CREATE TABLE IF NOT EXISTS `stadmin` (
  `Admin_id` varchar(20) NOT NULL,
  `Admin_pwd` varchar(20) NOT NULL,
  PRIMARY KEY (`Admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stadmin`
--

INSERT INTO `stadmin` (`Admin_id`, `Admin_pwd`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `stuser`
--

DROP TABLE IF EXISTS `stuser`;
CREATE TABLE IF NOT EXISTS `stuser` (
  `U_id` int(100) NOT NULL,
  `U_name` varchar(50) NOT NULL,
  `U_contact` varchar(20) NOT NULL,
  `U_email` varchar(20) NOT NULL,
  `U_pwd` varchar(20) NOT NULL,
  PRIMARY KEY (`U_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stuser`
--

INSERT INTO `stuser` (`U_id`, `U_name`, `U_contact`, `U_email`, `U_pwd`) VALUES
(1, 'a', 'a', 'a', 'a'),
(2, 's', 's', 's', 's');

-- --------------------------------------------------------

--
-- Table structure for table `toll`
--

DROP TABLE IF EXISTS `toll`;
CREATE TABLE IF NOT EXISTS `toll` (
  `Toll_id` int(30) NOT NULL,
  `City1` varchar(20) NOT NULL,
  `City2` varchar(20) NOT NULL,
  `Tax1` int(200) NOT NULL,
  `Tax2` int(200) NOT NULL,
  `Tax3` int(200) NOT NULL,
  PRIMARY KEY (`Toll_id`),
  KEY `City1` (`City1`),
  KEY `City2` (`City2`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `toll`
--

INSERT INTO `toll` (`Toll_id`, `City1`, `City2`, `Tax1`, `Tax2`, `Tax3`) VALUES
(1, 'Bengaluru', 'Pune', 20, 80, 120),
(2, 'Bengaluru', 'Goa', 30, 85, 115),
(3, 'Goa', 'Pune', 10, 10, 10),
(4, 'Gurgaon', 'Goa', 20, 20, 20);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

DROP TABLE IF EXISTS `vehicle`;
CREATE TABLE IF NOT EXISTS `vehicle` (
  `Veh_Regno` varchar(15) NOT NULL,
  `Veh_Type` varchar(15) NOT NULL,
  `U_id` int(100) NOT NULL,
  `Toll_id` int(30) NOT NULL,
  PRIMARY KEY (`Veh_Regno`),
  KEY `U_id` (`U_id`),
  KEY `Toll_id` (`Toll_id`),
  KEY `Veh_Type` (`Veh_Type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vehicletype`
--

DROP TABLE IF EXISTS `vehicletype`;
CREATE TABLE IF NOT EXISTS `vehicletype` (
  `Veh_Type` varchar(15) NOT NULL,
  PRIMARY KEY (`Veh_Type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`U_id`) REFERENCES `stuser` (`U_id`);

--
-- Constraints for table `qr_code`
--
ALTER TABLE `qr_code`
  ADD CONSTRAINT `qr_code_ibfk_1` FOREIGN KEY (`Trans_id`) REFERENCES `payment` (`Trans_id`),
  ADD CONSTRAINT `qr_code_ibfk_2` FOREIGN KEY (`U_id`) REFERENCES `stuser` (`U_id`),
  ADD CONSTRAINT `qr_code_ibfk_3` FOREIGN KEY (`Veh_Regno`) REFERENCES `vehicle` (`Veh_Regno`);

--
-- Constraints for table `toll`
--
ALTER TABLE `toll`
  ADD CONSTRAINT `toll_ibfk_1` FOREIGN KEY (`City1`) REFERENCES `citylist` (`City_name`),
  ADD CONSTRAINT `toll_ibfk_2` FOREIGN KEY (`City2`) REFERENCES `citylist` (`City_name`);

--
-- Constraints for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD CONSTRAINT `vehicle_ibfk_1` FOREIGN KEY (`U_id`) REFERENCES `stuser` (`U_id`),
  ADD CONSTRAINT `vehicle_ibfk_2` FOREIGN KEY (`Toll_id`) REFERENCES `toll` (`Toll_id`),
  ADD CONSTRAINT `vehicle_ibfk_3` FOREIGN KEY (`Veh_Type`) REFERENCES `vehicletype` (`Veh_Type`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
