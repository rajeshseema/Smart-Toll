package admin_dash;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Admin_process
 */
@WebServlet("/Admin_process")
public class Admin_process extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Admin_process() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String a_process = request.getParameter("why");
		if(a_process.equals("dash"))
		{
			Dash d=new Dash();
			String responsepage =d.dash(request);
			System.out.println("inside get");
			response.sendRedirect("include/dashboard.jsp");
		}
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String a_process = request.getParameter("why");
		if(a_process.equals("add-city"))
		{

			Add_City t =new Add_City();
			String responsepage = t.addcity(request);  
			System.out.println("see this on server" + responsepage);
			response.sendRedirect("include/add-cities.jsp");
			
		}
		else if(a_process.equals("add-emp"))
		{

			Add_Emp t =new Add_Emp();
			String responsepage = t.addemp(request);  
			System.out.println("see this on server" + responsepage);
			response.sendRedirect("include/add-employee.jsp");
			
		}
		else if(a_process.equals("add-toll"))
		{

			Add_Toll t =new Add_Toll();
			String responsepage = t.addtoll(request);  
			System.out.println("see this on server" + responsepage);
			response.sendRedirect("include/add-toll.jsp");
			
		}
		else if(a_process.equals("set-toll"))
		{

			Set_Toll t =new Set_Toll();
			String responsepage = t.settoll(request);  
			System.out.println("see this on server" + responsepage);
			response.sendRedirect("include/set-toll.jsp");
			
		}

		
		
	}
}
