package admin_dash;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;

public class Add_City {
	/*
	private String dbURL = "jdbc:mysql://localhost:3306/smarttolldatabase";
    private String dbUser = "root";
    private String dbPass = "";
	*/
	public String addcity(HttpServletRequest request) {
		 Connection mysqlCon = null;
	        Statement stmt = null;
	        String pn="include/add-cities.jsp";
	       
	        System.out.println("inside java");
	        //String city = request.getParameter("city");
	        try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            mysqlCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/smarttolldatabase", "root", "");
	            System.out.println("Connection successfull");
	            //stmt = mysqlCon.createStatement();
				//String sql="insert into citylist (City_name) values (+city)";
	            PreparedStatement st = mysqlCon.prepareStatement("insert into citylist values(?)"); 
	   
	             // For the first parameter, 
	             // get the data using request object 
	             // sets the data to st pointer 
	             //st.setInt(1, Integer.valueOf(request.getParameter("id"))); 
	   
	             // Same for second parameter 
	             st.setString(1, request.getParameter("city")); 
	            //stmt.executeUpdate(sql);
	             st.executeUpdate();
	             st.close(); 
	             mysqlCon.close();
	        } catch (Exception e) {
	            System.out.println(e);
	        }
	        
	          System.out.println("Done");
	          return pn;          
	}	
	
}

