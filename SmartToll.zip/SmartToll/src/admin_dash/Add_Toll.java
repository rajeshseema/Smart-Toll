package admin_dash;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;

public class Add_Toll {

	public String addtoll(HttpServletRequest request) {
		 Connection mysqlCon = null;
	        String pn="include/add-employee.jsp";
	       
	        System.out.println("inside java");
	        try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            mysqlCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/smarttolldatabase", "root", "");
	            System.out.println("Connection successfull");
	            PreparedStatement st = mysqlCon.prepareStatement("insert into toll values(?,?,?,?,?,?)"); 
	   
	             // For the first parameter, 
	             // get the data using request object 
	             // sets the data to st pointer 
	             //st.setInt(1, Integer.valueOf(request.getParameter("id"))); 
	   
	             // Same for second parameter 
	             st.setInt(1, Integer.valueOf(request.getParameter("tid"))); 
	             st.setString(2, request.getParameter("city1")); 
	             st.setString(3, request.getParameter("city2")); 
	             st.setInt(4, Integer.valueOf(request.getParameter("t1"))); 
	             st.setInt(5, Integer.valueOf(request.getParameter("t2"))); 
	             st.setInt(6, Integer.valueOf(request.getParameter("t3"))); 
	             
	             st.executeUpdate();
	             st.close(); 
	             mysqlCon.close();
	        } catch (Exception e) {
	            System.out.println(e);
	        }
	        
	          System.out.println("Done");
	          return pn;          
	}	
	


}
