package admin_dash;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Dash {
	public String dash(HttpServletRequest request) {
		 Connection mysqlCon = null;
	        Statement stmt = null;
	        String pn="include/add-cities.jsp";
	       
	        System.out.println("inside java");
	        ResultSet doc = null;
	       // List dataList= new ArrayList();
	        //String city = request.getParameter("city");
	        try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            mysqlCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/smarttolldatabase", "root", "");
	            System.out.println("Connection successfull");
	            //stmt = mysqlCon.createStatement();
				//String sql="insert into citylist (City_name) values (+city)";
	            String sql = "select count(*) from toll";
	            doc=stmt.executeQuery(sql);
                while (doc.next()) {
                    int no = doc.getInt(1);
                    request.setAttribute("no",no);
                    System.out.println(no);
                }   
               
	            mysqlCon.close();
	        } catch (Exception e) {
	            System.out.println(e);
	        }
	        
	          System.out.println("Done");
	          return pn;          
	}	
	

}
