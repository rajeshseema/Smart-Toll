package admin_dash;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;

public class Add_Emp {
	public String addemp(HttpServletRequest request) {
		 Connection mysqlCon = null;
	        String pn="include/add-employee.jsp";
	       
	        System.out.println("inside java");
	        try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            mysqlCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/smarttolldatabase", "root", "");
	            System.out.println("Connection successfull");
	            PreparedStatement st = mysqlCon.prepareStatement("insert into employee values(?,?,?)"); 
	   
	             // For the first parameter, 
	             // get the data using request object 
	             // sets the data to st pointer 
	             //st.setInt(1, Integer.valueOf(request.getParameter("id"))); 
	   
	             // Same for second parameter 
	             st.setInt(1, Integer.valueOf(request.getParameter("eid"))); 
	             st.setString(2, request.getParameter("ename")); 
	             st.setString(3, request.getParameter("epwd")); 

	             st.executeUpdate();
	             st.close(); 
	             mysqlCon.close();
	        } catch (Exception e) {
	            System.out.println(e);
	        }
	        
	          System.out.println("Done");
	          return pn;          
	}	
	

}
