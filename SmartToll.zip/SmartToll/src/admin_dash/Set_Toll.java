package admin_dash;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;

public class Set_Toll {
	public String settoll(HttpServletRequest request) {
		 Connection mysqlCon = null;
	        String pn="include/add-employee.jsp";
	       
	        System.out.println("inside java");
	        try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            mysqlCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/smarttolldatabase", "root", "");
	            System.out.println("Connection successfull");
	            PreparedStatement st = mysqlCon.prepareStatement("update toll set Tax1=?,Tax2=?,Tax3=? where Toll_id=? || City1=? && City2=?"); 
	   
	             // For the first parameter, 
	             // get the data using request object 
	             // sets the data to st pointer 
	             //st.setInt(1, Integer.valueOf(request.getParameter("id"))); 
	   
	             // Same for second parameter 
	             st.setInt(1, Integer.valueOf(request.getParameter("t1"))); 
	             st.setInt(2, Integer.valueOf(request.getParameter("t2"))); 
	             st.setInt(3, Integer.valueOf(request.getParameter("t3")));	             
	             st.setInt(4, Integer.valueOf(request.getParameter("tid"))); 
	             st.setString(5, request.getParameter("city1")); 
	             st.setString(6, request.getParameter("city2")); 
	             
	             st.executeUpdate();
	             st.close(); 
	             mysqlCon.close();
	        } catch (Exception e) {
	            System.out.println(e);
	        }
	        
	          System.out.println("Done");
	          return pn;          
	}	
	



}
